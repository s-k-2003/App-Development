package com.example.demo.dto.response;

public class FeedBackResponse {
    
}
