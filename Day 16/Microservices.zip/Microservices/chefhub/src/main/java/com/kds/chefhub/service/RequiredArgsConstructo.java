package com.kds.chefhub.service;

public @interface RequiredArgsConstructo {

}
