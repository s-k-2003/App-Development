package com.kds.chefhub.token;

public enum TokenType {
    BEARER
}
