package com.chefhub.paymentgate.dto.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PaymentRequest {
    private String transactionid;
    private String accountholder;
    private String type;
    private String amount;
    private String date;
    private String orderid;
}
