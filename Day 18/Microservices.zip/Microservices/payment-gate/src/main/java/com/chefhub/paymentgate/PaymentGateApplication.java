package com.chefhub.paymentgate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaymentGateApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaymentGateApplication.class, args);
	}

}
