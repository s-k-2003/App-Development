package com.chefhub.paymentgate.service;

import org.springframework.stereotype.Service;

import com.chefhub.paymentgate.dto.request.PaymentRequest;
import com.chefhub.paymentgate.model.Payment;
import com.chefhub.paymentgate.repository.PaymentRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class PaymentService {
    private final PaymentRepository paymentRepo;

    public String pay(PaymentRequest request){
        var transactions = Payment.builder()
        .transactionid(request.getTransactionid())
        .accountholder(request.getAccountholder())
        .type(request.getType())
        .amount(request.getAmount())
        .date(request.getDate())
        .orderid(request.getOrderid())
        .build();
        paymentRepo.save(transactions);

        return "Payment Sucessfull";
    }
}
