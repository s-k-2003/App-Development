package com.chefhub.paymentgate.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.chefhub.paymentgate.model.Payment;

public interface PaymentRepository extends JpaRepository<Payment, String>{
    
}
