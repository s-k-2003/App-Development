package com.kds.chefhub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChefhubApplicationTests {

	@Test
	void contextLoads() {
	}

}
